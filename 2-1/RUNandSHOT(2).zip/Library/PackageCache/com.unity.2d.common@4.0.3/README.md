2D Shared Code

- Triangle.net - a Unity friendly version of the triangle.net used to generate geometry.
- ImagePacker - fits  a list of textures or rects into a bigger rect. 