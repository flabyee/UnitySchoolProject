using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public Text waitForStartText;

    public GameObject obstaclePrefab = null;
    public GameObject exitDoorPrefab = null;

    public int spawnCount;

    private bool isSpawn;

    void Start()
    {
        DataManager.instance.t = 0;

        StartCoroutine(StartForStart());
        DataManager.instance.isExit = false;
        DataManager.instance.isKill = false;
        DataManager.instance.isOut = false;

        spawnCount = 0;
        isSpawn = true;
    }

    void Update()
    {
        if (!DataManager.instance.isShoting)
            DataManager.instance.t += Time.deltaTime;

        if(isSpawn)
        {
            if (DataManager.instance.t > DataManager.instance.spawnDelay)
            {
                if (spawnCount == 15)
                {
                    Instantiate(exitDoorPrefab, new Vector2(-10, -2.5f), Quaternion.identity);
                    isSpawn = false;
                }
                else
                {
                    DataManager.instance.t = 0;
                    Instantiate(obstaclePrefab, new Vector2(-10, -3), Quaternion.Euler(0, 0, 90));
                    spawnCount++;

                }
            }
        }
        
    }

    public void GameEnd()
    {
        if(DataManager.instance.isExit)
        {
            DataManager.instance.AddGold(DataManager.instance.score);  // Ż���ϸ� �� 2��
        }
        if(DataManager.instance.isKill)
        {
            DataManager.instance.AddGold(DataManager.instance.score * 2);  // ���̸� �� 3��
        }
        if(DataManager.instance.isOut)
        {
            DataManager.instance.SubGold(DataManager.instance.score / 2); // ���Ͱ� ���� ������ ������ 1/2��
        }
        DataManager.instance.AddGold(DataManager.instance.score);
        DataManager.instance.ResetScore();

        DataManager.instance.SaveData();

        SceneManager.LoadScene("LobyScene");
    }

    IEnumerator StartForStart()
    {
        Time.timeScale = 0;
        waitForStartText.text = "3";
        yield return new WaitForSecondsRealtime(1f);
        waitForStartText.text = "2";
        yield return new WaitForSecondsRealtime(1f);
        waitForStartText.text = "1";
        yield return new WaitForSecondsRealtime(1f);
        Time.timeScale = 1 + (DataManager.instance.playerSpeedLevel * 0.1f);
        waitForStartText.text = "START!";
        yield return new WaitForSecondsRealtime(1f);
        waitForStartText.gameObject.SetActive(false);
    }
}
